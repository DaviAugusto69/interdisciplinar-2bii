<?php

return[
    'host' => 'localhost',
    'name' => 'meu_mvc',
    'user' => 'meu_mvc_app',
    'pass' => 'uma-senha-forte-aqui',
    'charset' => 'utf8mb4',
];