<?php
declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$file = __DIR__ . DIRECTORY_SEPARATOR . ltrim((string) $path, '/\\');

if ($path !== '/' && is_file($file)) {
    return false;
}

require __DIR__ . '/index.php';